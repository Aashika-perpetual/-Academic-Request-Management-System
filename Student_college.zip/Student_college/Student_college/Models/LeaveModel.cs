﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace Student_college.Models
{
    public class LeaveModel
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        public string StudentId { get; set; }
        public string StudentName { get; set; }
        public string RollNo { get; set; }
        public string Reason { get; set; }

        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        public DateTime FromDate { get; set; }

        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        public DateTime ToDate { get; set; }

        public string Status { get; set; }
        public string SupportDocPath { get; set; }

        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // New fields
        public string? ReviewedBy { get; set; } // Teacher ID
        [BsonDateTimeOptions(Kind = DateTimeKind.Utc)]
        public DateTime? ReviewedAt { get; set; }
    }
}
