﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Student_college.Models
{
    public class Info
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }

        [BsonElement("student_id")]
        public string StudentId { get; set; }

        [BsonElement("leave")]
        public int Leave { get; set; }

        [BsonElement("bonafide")]
        public int Bonafide { get; set; }

        [BsonElement("email")]
        public string Email { get; set; }

        [BsonElement("password")]
        public string Password { get; set; }
    }
}
