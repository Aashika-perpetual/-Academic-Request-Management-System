﻿namespace Student_college.Models.ViewModel
{
    public class StudentDashboardViewModel
    {
        public string StudentId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Leave { get; set; }
        public int Bonafide { get; set; }
    }
}
