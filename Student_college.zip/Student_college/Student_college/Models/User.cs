﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Student_college.Models
{
    public class User
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }

        [BsonElement("student_id")]
        public string? StudentId { get; set; }

        [BsonElement("faculty_id")]
        public string? FacultyId { get; set; }

        [BsonElement("email")]
        public string Email { get; set; }

        [BsonElement("password")]
        public string Password { get; set; }

        [BsonElement("department")]
        public string Department { get; set; }

        [BsonElement("year")]
        public int? Year { get; set; } // only for students

        [BsonElement("name")]
        public string Name { get; set; }

        [BsonElement("designation")]
        public string? Designation { get; set; } // only for faculty

        [BsonElement("years_of_experience")]
        public int? YearsOfExperience { get; set; } // only for faculty

        [BsonElement("category")]
        public string Category { get; set; } // student or faculty
    }
}
