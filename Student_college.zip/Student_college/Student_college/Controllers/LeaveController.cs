﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Student_college.Models;
using System;
using System.IO;

namespace Student_college.Controllers
{
    public class LeaveController : Controller
    {
        private readonly IMongoCollection<LeaveModel> _leaveCollection;
        private readonly IMongoCollection<Info> _infoCollection;
        private readonly IWebHostEnvironment _environment;

        public LeaveController(IWebHostEnvironment environment)
        {
            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("test");
            _leaveCollection = database.GetCollection<LeaveModel>("leave");
            _infoCollection = database.GetCollection<Info>("info"); // ✅ Added this
            _environment = environment;
        }

        [HttpGet]
        public IActionResult ApplyLeave()
        {
            return View();
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public async Task<IActionResult> SubmitLeave(
            string StudentName,
            string RollNo,
            string Reason,
            DateTime FromDate,
            DateTime ToDate,
            IFormFile SupportDoc)
        {
            var studentId = HttpContext.Session.GetString("student_id");

            if (string.IsNullOrEmpty(studentId))
            {
                return Content("Session student_id is NULL or EMPTY during POST!");
            }

            string filePath = null;

            if (SupportDoc != null && SupportDoc.Length > 0)
            {
                var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
                if (!Directory.Exists(uploadsFolder))
                    Directory.CreateDirectory(uploadsFolder);

                var uniqueFileName = Guid.NewGuid().ToString() + "_" + SupportDoc.FileName;
                filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await SupportDoc.CopyToAsync(stream);
                }

                filePath = "/uploads/" + uniqueFileName;
            }

            var leave = new LeaveModel
            {
                StudentId = studentId,
                StudentName = StudentName,
                RollNo = RollNo,
                Reason = Reason,
                FromDate = FromDate,
                ToDate = ToDate,
                Status = "Pending",
                SupportDocPath = filePath
            };

            _leaveCollection.InsertOne(leave);

            // ✅ Increment leave count in info collection
            var update = Builders<Info>.Update.Inc(i => i.Leave, 1);
            _infoCollection.UpdateOne(i => i.StudentId == studentId, update);

            return RedirectToAction("StudentDash", "Dashboard");
        }
        [HttpGet]
        public IActionResult LeaveStatus()
        {
            var studentId = HttpContext.Session.GetString("student_id");
            if (string.IsNullOrEmpty(studentId))
                return RedirectToAction("SignIn", "Auth");

            var leaves = _leaveCollection.Find(l => l.StudentId == studentId).ToList();

            return View("status", leaves); 
        }
        public IActionResult Accepted()
        {
            var acceptedLeaves = _leaveCollection.Find(l => l.Status == "Accepted").ToList();
            return View("Accepted", acceptedLeaves);
        }

        public IActionResult Rejected()
        {
            var rejectedLeaves = _leaveCollection.Find(l => l.Status == "Rejected").ToList();
            return View("Rejected", rejectedLeaves);
        }
        public IActionResult TestSession()
        {
            var studentId = HttpContext.Session.GetString("student_id");
            return Content($"StudentId from session: {studentId ?? "null"}");
        }
    }
}
