﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Student_college.Models;

namespace Student_college.Controllers
{
    public class BonafideController : Controller
    {
        private readonly IMongoCollection<Info> _infoCollection;

        public BonafideController()
        {
            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("test");
            _infoCollection = database.GetCollection<Info>("info");
        }

        public IActionResult RequestBonafide()
        {
            return View();
        }

        [HttpPost]
        public IActionResult UpdateBonafide()
        {
            string studentId = HttpContext.Session.GetString("student_id");
            if (string.IsNullOrEmpty(studentId))
            {
                return Json(new { success = false, message = "Not logged in" });
            }

            var filter = Builders<Info>.Filter.Eq(i => i.StudentId, studentId);
            var update = Builders<Info>.Update.Inc(i => i.Bonafide, 1);

            var result = _infoCollection.UpdateOne(filter, update);

            if (result.ModifiedCount > 0)
            {
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = false, message = "Student not found or update failed" });
            }
        }
    }
}
