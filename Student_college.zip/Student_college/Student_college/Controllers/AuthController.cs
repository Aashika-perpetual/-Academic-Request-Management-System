﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using Student_college.Models;
using Microsoft.AspNetCore.Http;  

namespace Student_college.Controllers
{
    public class AuthController : Controller
    {
        private readonly IMongoCollection<User> _usersCollection;

        public AuthController()
        {
            // MongoDB connection setup
            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("test");
            _usersCollection = database.GetCollection<User>("users");
        }

        [HttpGet]
        public IActionResult SignIn()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> SignIn(string username, string password)
        {
            var user = await _usersCollection.Find(u => u.Email == username && u.Password == password).FirstOrDefaultAsync();

            if (user != null)
            {
                if (user.Category == "student")
                {
                    HttpContext.Session.SetString("student_id", user.StudentId ?? "");
                    HttpContext.Session.SetString("email", user.Email);
                    HttpContext.Session.SetString("name", user.Name);
                    await HttpContext.Session.CommitAsync();
                    return RedirectToAction("StudentDash", "Dashboard");
                }
                else if (user.Category == "faculty")
                {
                    HttpContext.Session.SetString("faculty_id", user.FacultyId ?? "");
                    HttpContext.Session.SetString("email", user.Email);
                    HttpContext.Session.SetString("name", user.Name);
                    await HttpContext.Session.CommitAsync();
                    return RedirectToAction("TeacherDash", "Dashboard");
                }
            }

            ViewBag.Error = "Invalid credentials.";
            return View();
        }
    }
}
