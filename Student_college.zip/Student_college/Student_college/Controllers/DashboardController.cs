﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using MongoDB.Bson;
using Student_college.Models;
using Student_college.Models.ViewModel;
using System.Collections.Generic;

namespace Student_college.Controllers
{
    public class DashboardController : Controller
    {
        private readonly IMongoCollection<User> _usersCollection;
        private readonly IMongoCollection<Info> _infoCollection;
        private readonly IMongoCollection<LeaveModel> _leaveCollection;

        public DashboardController()
        {
            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("test");

            _usersCollection = database.GetCollection<User>("users");
            _infoCollection = database.GetCollection<Info>("info");
            _leaveCollection = database.GetCollection<LeaveModel>("leave"); // 👈 Added leave collection
        }

        public IActionResult StudentDash()
        {
            string studentId = HttpContext.Session.GetString("student_id");
            if (string.IsNullOrEmpty(studentId))
                return RedirectToAction("SignIn", "Auth");

            var user = _usersCollection.Find(u => u.StudentId == studentId && u.Category == "student").FirstOrDefault();
            if (user == null)
                return RedirectToAction("SignIn", "Auth");

            var infoData = _infoCollection.Find(i => i.StudentId == studentId).FirstOrDefault();
            if (infoData == null)
                return RedirectToAction("SignIn", "Auth");

            var model = new StudentDashboardViewModel
            {
                StudentId = user.StudentId,
                Name = user.Name,
                Email = user.Email,
                Leave = infoData.Leave,
                Bonafide = infoData.Bonafide
            };

            return View("student_dash", model);
        }

        public IActionResult TeacherDash()
        {
            var pendingLeaves = _leaveCollection.Find(l => l.Status == "Pending").ToList(); // 👈 Get pending leaves
            return View("teacher_dash", pendingLeaves); // 👈 Send list to view
        }

        [HttpPost]
        public async Task<IActionResult> UpdateLeaveStatus(string id, string status)
        {
            var teacherId = HttpContext.Session.GetString("faculty_id"); // ✅ match your login
            if (string.IsNullOrEmpty(teacherId))
                return RedirectToAction("SignIn", "Auth"); // or show error

            var leave = await _leaveCollection.Find(x => x.Id == id).FirstOrDefaultAsync();
            if (leave == null)
                return NotFound();

            var update = Builders<LeaveModel>.Update
                .Set(l => l.Status, status)
                .Set(l => l.ReviewedBy, teacherId)
                .Set(l => l.ReviewedAt, DateTime.UtcNow);

            await _leaveCollection.UpdateOneAsync(x => x.Id == id, update);

            return RedirectToAction("TeacherDash");
        }
    }
}
